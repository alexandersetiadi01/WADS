// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyC7vM_Lf2kfhLkWeWH8Z_TJdrGzY-5Hwi4",
    authDomain: "ellery-setiadi-wads-exercise4.firebaseapp.com",
    databaseURL: "https://ellery-setiadi-wads-exercise4.firebaseio.com",
    projectId: "ellery-setiadi-wads-exercise4",
    storageBucket: "ellery-setiadi-wads-exercise4.appspot.com",
    messagingSenderId: "226549227263",
    appId: "1:226549227263:web:cd1c9a8df6b4e7722d36ca",
    measurementId: "G-PP8GXM7NEQ"
  }
};  

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
